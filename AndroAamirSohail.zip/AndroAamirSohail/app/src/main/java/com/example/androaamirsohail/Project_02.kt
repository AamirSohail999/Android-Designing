package com.example.androaamirsohail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class Project_02 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project02)


        var editTEXT = findViewById<EditText>(R.id.EdText)
        var Btn1 = findViewById<Button>(R.id.BTN)
        var Rad = findViewById<RadioButton>(R.id.radBtn)
        var CHKbox = findViewById<CheckBox>(R.id.CHKBOX)

        Rad.setOnClickListener{
            Toast.makeText(this, "Radio Button Triggered", Toast.LENGTH_LONG).show()

        }

        CHKbox.setOnClickListener{
            Toast.makeText(this, "CheckBox Triggered", Toast.LENGTH_LONG).show()

        }



    }
}