package com.example.ca3app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog

class IndexPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_index_page)
        var chk1 = findViewById<CheckBox>(R.id.checkBox)
        var chk2 = findViewById<CheckBox>(R.id.checkBox2)

        var lView = findViewById<ListView>(R.id.lv1)

        var b = arrayOf("Rice  -  20kg","Pulses  -  5kg","Tea  -  500gm","Sunflower Oil  -  5ltrs","Wheat  -  10kg")
        var ab = ArrayAdapter(this, android.R.layout.simple_list_item_1, b)

        lView.adapter = ab
        lView.setOnItemClickListener { adapterView, view, position, id ->
            var str = adapterView.getItemAtPosition(position) as String
            Toast.makeText(applicationContext, "you selected $str", Toast.LENGTH_SHORT).show()
        }

        chk1.setOnClickListener{
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Task Prompt")
                .setMessage("Are you sure, you have completed the Task!!")
                .setCancelable(false)
                .setIcon(android.R.drawable.ic_dialog_alert)


            //performing positive action
            builder.setPositiveButton("Yes"){
                    dialogInterface, which ->
                Toast.makeText(applicationContext, "Clicked Yes", Toast.LENGTH_LONG).show()

            }
            //performing cancel action
            builder.setNeutralButton("Cancel"){
                    dialogInterface, which ->
                Toast.makeText(applicationContext, "Clicked Cancel", Toast.LENGTH_LONG).show()

            }
            //performing negative action
            builder.setNegativeButton("No"){
                    dialogInterface, which ->
                Toast.makeText(applicationContext, "Clicked No", Toast.LENGTH_LONG).show()

            }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()


        }



        // access the items of the list
        val dresses = arrayOf("Denim+T-Shirt","Kurta","Tuxedo","Casual","Torso+Hoodie")

        // access the spinner
        val spinner = findViewById<Spinner>(R.id.spinner)

        if (spinner != null) {
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, dresses)
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,view: View, position: Int, id: Long) {
                    Toast.makeText(this@IndexPage,
                        "Selected Item" + " " + dresses[position],
                        Toast.LENGTH_SHORT).show()
                    var outp:String = dresses[position]

                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.optionmenu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return when (id){
            R.id.Save -> {
                Toast.makeText(applicationContext, "Save Selected", Toast.LENGTH_LONG).show()
                true
            }
            R.id.FAQ -> {
                Toast.makeText(applicationContext, "FAQ Selected", Toast.LENGTH_LONG).show()
                true
            }
            R.id.About -> {
                Toast.makeText(applicationContext, "About Selected", Toast.LENGTH_LONG).show()
                true
            }
            R.id.Logout -> {
                Toast.makeText(applicationContext, "Log out Selected", Toast.LENGTH_LONG).show()
                System.exit(0)
                true
            }
            else -> super.onOptionsItemSelected(item)

        }
    }
}