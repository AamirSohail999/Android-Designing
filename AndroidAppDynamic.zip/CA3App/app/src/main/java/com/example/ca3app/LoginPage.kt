package com.example.ca3app

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts

class LoginPage : AppCompatActivity() {
    lateinit var imageUri:Uri
    lateinit var getImage:ActivityResultLauncher<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        val btnSignUp =findViewById<Button>(R.id.button2)
        val btnLogin = findViewById<Button>(R.id.button)
        var btnCam = findViewById<Button>(R.id.button3)
        var btnGallery = findViewById<Button>(R.id.button4)
        var imgV = findViewById<ImageView>(R.id.imageView)

        getImage = registerForActivityResult(ActivityResultContracts.GetContent(),
            ActivityResultCallback {
                imageUri=it
                imgV.setImageURI(it)
            })

        btnGallery.setOnClickListener {
            getImage.launch("image/*")
        }

        val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission())
        {
            if(it)
            {
                Toast.makeText(applicationContext,"Permission Granted",Toast.LENGTH_LONG).show()
                setActivityResult()
                finish()
            }
            else
            {
                Toast.makeText(applicationContext,"Permission Denied",Toast.LENGTH_LONG).show()
            }
        }
        btnCam.setOnClickListener {
            requestCamera.launch(android.Manifest.permission.CAMERA)
        }


        btnSignUp.setOnClickListener {
            val intentSign = Intent(this, SignUp::class.java)
            startActivity(intentSign)
        }


        btnLogin.setOnClickListener {
            val intentLog = Intent(this, IndexPage::class.java)
            startActivity(intentLog)
        }



    }
    private fun setActivityResult() {
        val camera_intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivity(camera_intent)

    }
}